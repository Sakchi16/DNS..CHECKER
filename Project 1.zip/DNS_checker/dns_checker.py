import threading
import tkinter as tk
from tkinter import messagebox, ttk
from scapy.all import *
import socket
import psutil
import logging
from queue import Queue
import ipaddress  # For IP validation

# Constants and Globals
TRUSTED_DNS_SERVER = "8.8.8.8"
is_detection_active = False
selected_interface = None
gui_queue = Queue()

LOG_FILE = "dns_traffic_log.txt"
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# Function to validate if the given value is an IP address
def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

# DNS Query Function
def query_dns(domain):
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None

# Packet Processing Function
def detect_spoof(packet):
    if not is_detection_active:
        return

    # Ensure the packet has DNS and DNSRR layers
    if not (packet.haslayer(DNS) and packet.haslayer(DNSRR)):
        return

    if packet[DNS].qr == 1:  # Check if it's a response
        queried_domain = packet[DNSQR].qname.decode().strip(".")
        spoofed_ip = packet[DNSRR].rdata

        # Validate if the spoofed IP is a valid IP address
        if not is_valid_ip(spoofed_ip):
            print(f"Invalid IP received for {queried_domain}: {spoofed_ip}")
            return  # Ignore invalid IP addresses

        # Ignore all Google subdomains except specific ones
        if queried_domain.endswith(".google.com"):
            if not (queried_domain == "accounts.google.com" or queried_domain == "mail.google.com"):
                print(f"Ignoring packet from {queried_domain}")
                return

        log_packet(queried_domain, spoofed_ip)

        trusted_ip = query_dns(queried_domain)
        if trusted_ip is None:
            print(f"Could not query trusted DNS server for {queried_domain}")
            return

        if spoofed_ip != trusted_ip:
            print(f"[ALERT] DNS Spoofing Detected for {queried_domain}")
            log_incident(queried_domain, spoofed_ip, trusted_ip, spoofed=True)
            halt_and_warn(queried_domain, spoofed_ip, trusted_ip)
        else:
            log_incident(queried_domain, spoofed_ip, trusted_ip, spoofed=False)

# Logging Functions
def log_packet(domain, ip):
    logging.info(f"DNS Query Logged - Domain: {domain}, IP: {ip}")

def log_incident(domain, spoofed_ip, trusted_ip, spoofed=False):
    if spoofed:
        logging.warning(
            f"DNS Spoofing Detected - Domain: {domain}, Received IP: {spoofed_ip}, Trusted IP: {trusted_ip}"
        )
    else:
        logging.info(
            f"DNS Query Confirmed - Domain: {domain}, Received IP: {spoofed_ip}, Matches Trusted IP: {trusted_ip}"
        )

# Warning and Halt Function
def halt_and_warn(domain, spoofed_ip, trusted_ip):
    gui_queue.put((domain, spoofed_ip, trusted_ip))

# GUI Queue Processing
def process_gui_queue():
    while not gui_queue.empty():
        domain, spoofed_ip, trusted_ip = gui_queue.get()

        warning_window = tk.Toplevel()
        warning_window.title("DNS Spoofing Warning")
        warning_window.geometry("400x200")
        warning_label = tk.Label(
            warning_window,
            text=(
                f"Potential DNS Spoofing Detected!\n\n"
                f"Domain: {domain}\n"
                f"Received IP: {spoofed_ip}\n"
                f"Trusted IP: {trusted_ip}\n\n"
                f"Do you want to continue?"
            ),
            wraplength=350,
            justify="left",
        )
        warning_label.pack(pady=10)

        tk.Button(warning_window, text="Continue", command=warning_window.destroy).pack(side="left", padx=20, pady=20)
        tk.Button(warning_window, text="Halt Connection", command=warning_window.destroy).pack(side="right", padx=20, pady=20)

# Packet Sniffing Function
def sniff_packets():
    sniff(filter="udp port 53", iface=selected_interface, prn=detect_spoof, store=False)

# Start/Stop Detection
def toggle_detection(status_label):
    global is_detection_active

    if not selected_interface:
        messagebox.showerror("Error", "Please select a network interface before starting!")
        return

    if is_detection_active:
        is_detection_active = False
        status_label.config(text="Status: OFF", fg="red")
    else:
        is_detection_active = True
        status_label.config(text="Status: ON", fg="green")
        threading.Thread(target=sniff_packets, daemon=True).start()

# List Network Interfaces
def list_interfaces():
    interfaces = psutil.net_if_addrs()
    return list(interfaces.keys())

# GUI Initialization
def start_gui():
    global selected_interface

    root = tk.Tk()
    root.title("DNS Spoof Detection Tool")
    root.geometry("400x300")

    # Status Label
    status_label = tk.Label(root, text="Status: OFF", fg="red", font=("Arial", 12))
    status_label.pack(pady=10)

    # Interface Selection
    interface_label = tk.Label(root, text="Select Network Interface:")
    interface_label.pack()

    interface_list = list_interfaces()
    interface_combo = ttk.Combobox(root, values=interface_list, state="readonly", width=30)
    interface_combo.pack(pady=10)

    def set_interface():
        global selected_interface
        selected_interface = interface_combo.get()
        if selected_interface:
            print(f"Selected Interface: {selected_interface}")

    select_button = tk.Button(root, text="Set Interface", command=set_interface)
    select_button.pack(pady=5)

    # Toggle Detection Button
    toggle_button = tk.Button(
        root,
        text="ON/OFF",
        command=lambda: toggle_detection(status_label),
        width=10,
        height=2,
    )
    toggle_button.pack(pady=20)

    # Process GUI Queue Continuously
    def update_gui():
        process_gui_queue()
        root.after(100, update_gui)

    update_gui()
    root.mainloop()

# Main Entry Point
if __name__ == "__main__":
    start_gui()
